;*************************************************************************************
;*********************** SECTION 1: FIXED POINT MATH FUNTIONS ************************ 
;*************************************************************************************
Thank you for trying C28x Software Collateral. 
Fixed Point MATH Library is installed in C:\TIDCS\C28\DSP_TBOX\QMATH directory.


Fixed point math library (QMATH) contains math/trigonometric routines that are developed 
as an easy-to-use library, which has to be linked to the user�s application. 
The following table summarizes the set of functions that are defined in this library.

FIXED POINT MATH FUNTIONS
|===============|=======================================================================|
|  Module Name	| Description						        	|
|===============|=======================================================================| 
|  QSIN		| Fixed point SIN (Taylor series implementation)		  	|
|---------------|-----------------------------------------------------------------------|
|  QSINLT	| Fixed point SIN (Table look-up and linear interpolation)		|
|---------------|-----------------------------------------------------------------------|
|  QCOS		| Fixed point COS (Taylor series implementation)			|
|---------------|-----------------------------------------------------------------------|
|  QCOSLT	| Fixed Point COS (Table look-up and linear interpolation)		|
|---------------|-----------------------------------------------------------------------|
|  QATAN	| Fixed point ATAN (Taylor series implementation)			|
|---------------|-----------------------------------------------------------------------|
|  QSQRT	| Fixed point Square-root (Taylor series implementation)		|
|---------------|-----------------------------------------------------------------------|
|  QLOG10 	| Fixed point LOG10 (Taylor series implementation)			|
|---------------|-----------------------------------------------------------------------|
|  QLOGN	| Fixed point LOGN (Taylor series implementation)			|
|---------------|-----------------------------------------------------------------------|
|  QINV1	| Reciprocal (32-bit Precision)						|
|---------------|-----------------------------------------------------------------------|
|  QINV2	| Reciprocal (16-bit Precision)						|
|---------------|-----------------------------------------------------------------------|
|  QDIV		| Division 								|
|=======================================================================================|
 

DOCUMENTATION:
|===============|=======================================================================|
|  DOC		| DIRECTORY LOCATION				        		|
|===============|=======================================================================| 
|  MODULE DOC	| C:\TIDCS\C24\DSP_TBOX\MATH\DOC\MATH_MDL.PDF		  		|
|=======================================================================================|



Version History:
================

Version 0.9a dated 12/06/2003 

1. Some the math function had .ref being used in the *.asm, it is changed to .def 
   Because of this bug, compiler was reporting that the function name is not available.

2. Most of the functions did not clear the OVM flag at the end, it is modified.

3. ASP & NASP is been used within functions, we should not disturb the ASP bit.
   It is meant for only interrupt handler. Called function should not change this bit.

